# Punto 2 — Diseño con Programación Orientada a Aspectos (AOP)

## 2.1. Propósito del diseño

El objetivo es diseñar cómo aplicar Programación Orientada a Aspectos (AOP) para entrenar un modelo de regresión lineal mediante descenso de gradiente, separando la lógica matemática central de las funcionalidades transversales.

## 2.2. Arquitectura General

### A) Capa CORE

Contiene únicamente la lógica matemática del modelo:

- `predict(X)`
- `compute_gradients(X, y)`
- `update_params(dw, db, lr)`
- `train_epoch(X, y, lr)`

Atributos: `w`, `b`.

### B) Capa de ASPECTOS

Aspectos transversales que agregan funcionalidad sin alterar la lógica del core:

1. LoggingAspect
2. MetricsAspect
3. ValidationAspect
4. CheckpointAspect
5. RetryAspect
6. ProfilerAspect
7. HyperparamSchedulerAspect
8. SecurityAspect
9. ExperimentationAspect

## 2.3. Pointcuts principales

- **pc\_predict\_call**: llamado a `predict(...)`
- **pc\_compute\_gradients\_call**: llamado a `compute_gradients(...)`
- **pc\_update\_params\_call**: llamado a `update_params(...)`
- **pc\_epoch\_start**: inicio de `train_epoch(...)`
- **pc\_epoch\_end**: fin de `train_epoch(...)`
- **pc\_checkpoint\_event**: evento de guardado de parámetros
- **pc\_io\_operations**: operaciones de entrada/salida

## 2.4. Advices por aspecto

### LoggingAspect

- **before(pc\_epoch\_start)**: registra inicio de la época.
- **after(pc\_epoch\_end)**: registra MSE y duración.
- **around(pc\_compute\_gradients\_call)**: registra entrada y salida.

### MetricsAspect

- **after(pc\_compute\_gradients\_call)**: registra normas de gradientes.
- **after(pc\_epoch\_end)**: almacena métricas globales.

### ValidationAspect

- **before(pc\_predict\_call)**: valida formato de `X`.
- **before(pc\_compute\_gradients\_call)**: valida coherencia entre `X` y `y`.

### CheckpointAspect

- **after(pc\_epoch\_end)** (condicional): guarda pesos si mejora.
- **around(pc\_checkpoint\_event)**: protege la operación.

### RetryAspect

- **around(pc\_io\_operations)**: reintentos con backoff.

### ProfilerAspect

- **around(pc\_compute\_gradients\_call)** y **around(pc\_update\_params\_call)**: mide tiempos.

### HyperparamSchedulerAspect

- **after(pc\_epoch\_end)**: ajusta learning rate.

### SecurityAspect

- **before(pc\_predict\_call)**: verifica permisos.
- **before(pc\_update\_params\_call)**: controla acceso.

### ExperimentationAspect

- **before(pc\_epoch\_start)**: registra metadata del experimento.

## 2.5. Descripción del diagrama conceptual

### **Diagrama conceptual (ASCII)**

```
                      +-----------------------------+
                      |    HyperparamSchedulerAspect |
                      +-----------------------------+
                                  ^
                                  |
        +----------------+     +------------------+     +----------------+
        | LoggingAspect  | <-- | LinearRegression | --> | MetricsAspect  |
        +----------------+     |      Core        |     +----------------+
               ^               |  (w, b, predict, |             ^
               |               |   gradients...)  |             |
        +----------------+     +------------------+     +----------------+
        |SecurityAspect  |           ^   ^               |ProfilerAspect |
        +----------------+           |   |               +----------------+
               ^                     |   |
               |                     |   |
        +----------------+           |   +-------------------------+
        |ValidationAspect|           |                             |
        +----------------+     +----------------+           +----------------+
               ^               |CheckpointAspect|           |RetryAspect     |
               |               +----------------+           +----------------+
               |                             ^                        ^
               +-----------------------------+------------------------+
                                  |
                        +------------------------+
                        |ExperimentationAspect   |
                        +------------------------+
```

El `LinearRegressionCore` se ubica al centro, mientras que cada aspecto lo rodea e intercepta llamadas según los pointcuts.

## 2.6. Código de ejemplo explicativo (no implementación completa)

A continuación se incluye un fragmento **solo ilustrativo**, que muestra cómo se vería la estructura con pointcuts y advices. No es código ejecutable, es pseudocódigo AOP:

```java
// --- CORE LIMPIO ---
class LinearRegressionCore {
    double w = 0.0;
    double b = 0.0;

    double predict(double X) {
        return w * X + b;                      // pc_predict_call
    }

    Gradients compute_gradients(double[] X, double[] y) {
        // pc_compute_gradients_call
        // Lógica matemática pura
        return new Gradients(dw, db);
    }

    void update_params(double dw, double db, double lr) {
        // pc_update_params_call
        w -= lr * dw;
        b -= lr * db;
    }

    void train_epoch(double[] X, double[] y, double lr) {
        // pc_epoch_start
        var grads = compute_gradients(X, y);
        update_params(grads.dw, grads.db, lr);
        // pc_epoch_end
    }
}

// --- ASPECTOS ---
aspect LoggingAspect {
    before(pc_epoch_start):
        log("[Epoch] Inicio de época");

    after(pc_epoch_end):
        log("[Epoch] Fin de época, MSE=" + metrics.mse);
}

aspect ValidationAspect {
    before(pc_predict_call):
        if (X is null) throw Error("Entrada inválida en predict()");
}

aspect MetricsAspect {
    after(pc_compute_gradients_call):
        metrics.dw_norm = norm(dw);
        metrics.db_norm = norm(db);
}

aspect CheckpointAspect {
    after(pc_epoch_end) when (metrics.improved):
        save_checkpoint(w, b);
}
```

---

## 2.7. Justificación

El diseño mantiene el core completamente limpio, modulariza las funcionalidades transversales y permite activar, desactivar o combinar aspectos sin modificar la lógica matemática del modelo. El diseño mantiene el core completamente limpio, modulariza las funcionalidades transversales y permite mantener, extender o activar/desactivar aspectos sin tocar la lógica matemática del modelo. Es un diseño escalable, formal y alineado con el paradigma AOP.

