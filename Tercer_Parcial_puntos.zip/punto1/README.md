# Diseño detallado: Regresión Lineal usando Concurrencia y Cálculo de PI

## 1. Objetivo del diseño
Diseñar una arquitectura concurrente que permita ejecutar el algoritmo de regresión lineal distribuyendo el cálculo del *gradiente* (dw y db) entre múltiples hilos/procesos. Además, se integrará el paradigma del cálculo de PI como técnica para sincronización, división de trabajo o esquema maestro‑trabajador.

---
## 2. Descripción general del sistema
El sistema se compone de **tres capas** principales:

### **A. Capa de Entrada**
- Recibe `X`, `y`, learning_rate y epochs.
- Valida el tamaño de los datos.
- Divide los datos en particiones para el cálculo concurrente.

### **B. Capa de Procesamiento Concurrente**
Esta es la más importante. Se estructura con el paradigma de concurrencia y cálculo de PI.

Incluye:

#### **1. Módulo Maestro (Coordinator)**
- Controla el valor global de `w` y `b`.
- Envía a cada trabajador un segmento de los datos.
- Recibe los gradientes parciales generados por cada trabajador.
- Combina los gradientes parciales:
  - `dw_total = suma(dw_i)`
  - `db_total = suma(db_i)`
- Actualiza los parámetros globales.
- Coordina el número de epochs.

#### **2. Módulo Trabajadores (Workers)**
Cada worker procesa sólo una parte de los datos:
- Recibe `X_segment`, `y_segment`, y los parámetros actuales `w` y `b`.
- Calcula:
  - `error = (w * X_segment + b) - y_segment`
  - `dw_i = sum(error * X_segment)`
  - `db_i = sum(error)`
- Retorna sus gradientes parciales al maestro.

#### **3. Uso del Paradigma de Cálculo de PI**
La idea es usar el cálculo de PI como analogía de **división del trabajo en intervalos**:

En cálculo de PI:
- Se divide el intervalo `[0,1]` en `n` partes.
- Cada proceso calcula el área de un segmento.
- El maestro suma los resultados.

Aquí hacemos lo mismo:
- Se divide el dataset en `n` segmentos.
- Cada worker calcula el "área parcial" del gradiente.
- El maestro suma para obtener el gradiente total.

Se replica la misma esencia del algoritmo de PI:
1. División del trabajo.
2. Procesamiento paralelo.
3. Reducción (reduce operation): suma de resultados parciales.
4. Actualización global.

#### **4. Sincronización**
- Se utiliza un **barrier** para asegurar que todos los workers terminen antes de que el maestro actualice `w` y `b`.
- Se usa un **lock** para proteger las variables globales en caso de que workers reporten resultados en un buffer compartido.

---
## 3. Flujo detallado del algoritmo (Diseño)

### **Paso 1: Inicialización**
- Se definen `w = 0`, `b = 0`.
- Se define el número de workers (por ejemplo 4).
- El maestro divide `X` y `y` en 4 segmentos.

### **Paso 2: Loop de entrenamiento (epochs)**

Para cada epoch:

#### **2.1 Broadcast de parámetros**
- El maestro envía `w` y `b` a todos los workers.

#### **2.2 Cálculo concurrente del gradiente**
Cada worker hace:
- Recibe segmento.
- Calcula error parcial.
- Calcula `dw_i` y `db_i`.
- Devuelve resultados.

#### **2.3 Reducción (reduce)**
El maestro:
- Suma todos los `dw_i`.
- Suma todos los `db_i`.
- Calcula:
  - `dw = (2/m) * dw_total`
  - `db = (2/m) * db_total`

#### **2.4 Actualización global**
- `w -= learning_rate * dw`
- `b -= learning_rate * db`

#### **2.5 Registro opcional del costo**
- El maestro calcula y almacena el MSE.

---
## 4. Diagrama de Arquitectura (Descripción)

```
                +----------------------------+
                |         MAESTRO           |
                |  - controla w, b          |
                |  - merge de gradientes    |
                +-------------+--------------+
                              |
   -------------------------------------------------------
   |                |                 |                 |
+------+       +---------+       +---------+       +---------+
|Worker|       | Worker  |       | Worker  |       | Worker  |
|  1   |       |    2    |       |    3    |       |    4    |
+------+       +---------+       +---------+       +---------+
   |                |                 |                 |
Calculo parcial   Calculo parcial   Calculo parcial   Calculo parcial
   |                |                 |                 |
   ----------------- resultados parciales ----------------->

```

---
## 5. Justificación del uso de concurrencia
- Reduce tiempo de entrenamiento si el dataset es grande.
- Emula esquemas distribuidos reales como MapReduce.
- Cada worker trabaja sin bloquear a los demás.
- Se aprovechan múltiples núcleos.

---
## 6. Justificación del uso del cálculo de PI
Usamos el paradigma clásico del cálculo paralelo de PI como referencia porque:
- Tiene la misma estructura de división del trabajo.
- Es un problema de integración fácil de mapear a gradientes.
- Permite explicar claramente la sincronización y reducción.
- Es comúnmente usado para enseñar concurrencia.

---
## 7. Entregables dentro del diseño
- Diagrama general del sistema.
- Descripción del maestro.
- Descripción de los workers.
- Explicación del uso del cálculo de PI.
- Flujo detallado del algoritmo.
- Justificación del enfoque concurrente.

---
## 8. Estado final del modelo (conceptual)
Al final, el maestro obtiene valores `w` y `b` entrenados de la misma forma que el código original, pero ahora **optimizando el cálculo mediante concurrencia y diseño inspirado en cálculo de PI**.


