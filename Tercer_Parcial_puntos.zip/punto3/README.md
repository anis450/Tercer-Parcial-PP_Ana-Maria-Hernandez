# Proyecto de Regresión Lineal en Python y Rust

Este proyecto implementa la regresión lineal mediante descenso de gradiente en dos lenguajes distintos: **Python** y **Rust**. La intención es mostrar cómo se expresa el mismo algoritmo en dos entornos con filosofías muy diferentes, destacando claridad, organización y estilo.

---

## 1. ¿Qué contiene este proyecto?

El ZIP incluye tres elementos principales:

- `` → Implementación en Python usando NumPy.
- `` → Implementación en Rust desde cero (sin librerías externas).
- `` → Resumen comparativo entre Python y Rust.

No incluye mediciones de tiempo ni gráficos, ya que esta versión se enfoca únicamente en el funcionamiento del algoritmo y la comparación conceptual.

---

## 2. Explicación del código en Python (`regression.py`)

El archivo implementa:

- Inicialización de parámetros `w` (pendiente) y `b` (intercepto).
- Cálculo de la predicción: \(y_{pred} = wX + b\)
- Cálculo del error entre predicción y valor real.
- Cálculo de gradientes para `w` y `b`.
- Descenso de gradiente para ajustar los parámetros: \(w = w - lr \cdot dw\) \(b = b - lr \cdot db\)
- Entrenamiento del modelo durante varias épocas.
- Predicción con el modelo entrenado.

**Python es ideal** cuando se quiere código sencillo, limpio y muy fácil de entender.

---

## 3. Explicación del código en Rust (`main.rs`)

La versión en Rust sigue la misma lógica pero con:

- Tipos estrictos.
- Manejo seguro de memoria.
- Mayor control sobre cada operación.

El archivo:

- Define vectores `X` y `y`.
- Calcula predicción, gradientes y actualiza parámetros.
- Entrena el modelo durante varias épocas.
- Imprime los valores finales aprendidos.

**Rust es ideal** cuando se necesita rendimiento alto y seguridad total.

---

## 4. Archivo de conclusiones (`conclusiones.md`)

Este documento resume:

- Diferencias de estilo entre Python y Rust.
- Qué lenguaje es más adecuado según el caso.
- Observaciones generales del algoritmo.

---

## 5. Estructura del proyecto

```
proyecto_regresion/
│
├─ python/
│    └─ regression.py
│
├─ rust/
│    └─ main.rs
│
└─ conclusiones/
     └─ conclusiones.md
```



## Cómo ejecutar el código

### 🔵 Ejecutar el código en Python

1. Asegúrate de tener Python 3 instalado.
2. Instala NumPy:
   ```bash
   pip install numpy
   ```
3. Entra a la carpeta `python/` del proyecto:
   ```bash
   cd python
   ```
4. Ejecuta el archivo:
   ```bash
   python regression.py
   ```
5. Verás en consola el entrenamiento, los valores finales de `w` y `b`, y la predicción final.

---

### 🟠 Ejecutar el código en Rust

1. Instala Rust y Cargo ([https://www.rust-lang.org/](https://www.rust-lang.org/)).
2. Entra a la carpeta `rust/` del proyecto:
   ```bash
   cd rust
   ```
3. Compila el programa:
   ```bash
   cargo build
   ```
4. Ejecútalo:
   ```bash
   cargo run
   ```
5. Se mostrará el entrenamiento del modelo y los parámetros finales aprendidos.

---

