use std::time::Instant;

fn train_linear_regression(x: &Vec<f64>, y: &Vec<f64>, lr: f64, epochs: usize) -> (f64, f64) {
    let mut w = 0.0;
    let mut b = 0.0;
    let n = x.len() as f64;

    for _ in 0..epochs {
        let mut dw = 0.0;
        let mut db = 0.0;

        for i in 0..x.len() {
            let y_pred = w * x[i] + b;
            dw += (y_pred - y[i]) * x[i];
            db += y_pred - y[i];
        }

        dw = 2.0/n * dw;
        db = 2.0/n * db;

        w -= lr * dw;
        b -= lr * db;
    }
    (w, b)
}

fn main() {
    let mut x = Vec::new();
    let mut y = Vec::new();
    for i in 0..100 {
        let xi = i as f64 * 0.1;
        x.push(xi);
        y.push(3.0*xi + 7.0);
    }

    let start = Instant::now();
    let (w, b) = train_linear_regression(&x, &y, 0.01, 1000);
    let duration = start.elapsed();

    println!("Rust -> w={:?}, b={:?}, tiempo={:?}", w, b, duration);
}
