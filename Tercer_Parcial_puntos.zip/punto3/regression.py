import time
import numpy as np

def train_linear_regression(X, y, lr=0.01, epochs=1000):
    w, b = 0.0, 0.0
    n = len(X)
    for _ in range(epochs):
        y_pred = w * X + b
        dw = (2/n) * np.sum((y_pred - y) * X)
        db = (2/n) * np.sum(y_pred - y)
        w -= lr * dw
        b -= lr * db
    return w, b

if __name__ == "__main__":
    X = np.linspace(0, 10, 100)
    y = 3*X + 7 + np.random.randn(100)

    start = time.time()
    w, b = train_linear_regression(X, y)
    end = time.time()

    print(f"Python -> w={w}, b={b}, tiempo={end-start}")
